#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "function.h"

// main function to perform main task
int main()
{

    // Task 1: Enter student number
    int number;
    printf("Enter number of student: ");
    scanf("%d", &number);
    getchar();
    struct studentInfo student[number];

    // loop for enter the number again if too high
    while (number > 1000)
    {
        printf("Invalid number. Please enter again: ");
        scanf("%d", &number);
    }

    // Task 2: Enter students' information: ID, full name, birthdate, grade of 3 subjects
    for (int i = 0; i < number; i++)
    {
        printf("Enter student %d name: ", i + 1);
        fgets(student[i].fullName, 30, stdin);
        student[i].fullName[strcspn(student[i].fullName, "\n")] = '\0';
        

        printf("Enter student %d ID: ", i + 1);
        fgets(student[i].ID, 30, stdin);
        student[i].ID[strcspn(student[i].ID, "\n")] = '\0';
        checkID(student[i].ID);

        printf("Enter student %d birthdate (dd/mm/yyyy): ", i + 1);
        fgets(student[i].birthDate, 11, stdin);
        student[i].birthDate[strcspn(student[i].birthDate, "\n")] = '\0';
        checkBirthDate(student[i].birthDate);

        printf("Enter student %d Linear Algebra score: ", i + 1);
        scanf("%f", &student[i].algebra);
       
        checkGradeAlgebra(&student[i].algebra);

        printf("Enter student %d Calculus score: ", i + 1);
        scanf("%f", &student[i].calculus);
        
        checkGradeCalculus(&student[i].calculus);

        printf("Enter student %d Basic Programming score: ", i + 1);
        scanf("%f", &student[i].basicProgramming);
        checkGradeCalculus(&student[i].basicProgramming);

        // print the information after getting input to check if the input is correct or not
        printf("\n--------------------\n");

        printf("Student %d name: %s\n", i + 1, student[i].fullName);

        printf("Student %d ID: %s\n", i + 1, student[i].ID);

        printf("Student %d birthdate: %s\n", i + 1, student[i].birthDate);

        printf("Student %d Linear Algebra: %.2f\n", i + 1, student[i].algebra);

        printf("Student %d Calculus: %.2f\n", i + 1, student[i].calculus);

        printf("Student %d Basic Programming: %.2f\n", i + 1, student[i].basicProgramming);

        printf("--------------------\n");

        getchar();

        printf("The GPA of student is: %.2f\n", calculateGPA(&student[i].algebra, &student[i].calculus, &student[i].basicProgramming));
        printf("--------------------\n");
    }
   

    // Task3 - print student list as a table to screen
    printf("Table of information\n");
    printTable(student, number);
    printf("\n--------------------\n");

    // Task 4: print student list as a table to a texxt file
    writeToFile(number, student);

    // Task 5: Process grades
    highestGPA(student, number);
    lowestGPA(student, number);
    highestBP(student, number);
    printf("\n--------------------\n");

    // Task 6: Print out student lastName
    printf("FirstName of students:\n");
    for (int i = 0; i < number; i++)
    {
        getFirstName(student[i].fullName);
    }
    printf("\n--------------------\n");

    printf("LastName of students:\n");
    for (int i = 0; i < number; i++)
    {
        getLastName(student[i].fullName);
    }
    printf("\n--------------------\n");

    // Task 10: Sort the student list by GPA in descending order
    printf("GPA of students in descending order: \n");
    quickSortGPA(student, 0, number - 1, 1);
    printTable(student, number);
    printf("\n--------------------\n");

    return 0;
}
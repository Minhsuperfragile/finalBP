#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// define a struct 

typedef struct studentInfo
{
    char fullName[30], ID[30], birthDate[11];
    float algebra, calculus, basicProgramming, GPA;
} student;

// function to check input information

// function to check ID
void checkID(char *ID)
{
    
        while (strlen(ID)> 12 || strlen(ID)< 1)
        {
            printf("Invalid student ID. Enter the information again: ");
            fgets(ID, 30, stdin);
            ID[strcspn(ID, "\n")] = '\0';
        }
    
}

// function to check birthdate

void checkBirthDate(char *birthDay)

{
    int temp;
    char strOfBirthDate[50];
    strcpy(strOfBirthDate, birthDay);
    char *token, *last;
    last = token = strtok(strOfBirthDate, "/");

    while (token != NULL)
    {
        last = token;
        token = strtok(NULL, "/");
    }
    temp = atoi(last);
    

    while (temp < 1800)
    {
        
        printf("Invalid birthdate. Enter the information again: ");
        fgets(birthDay, 11, stdin);
        birthDay[strcspn(birthDay, "\n")] = '\0';
        strcpy(strOfBirthDate, birthDay);
        last = token = strtok(strOfBirthDate, "/");

        while (token != NULL)
        {
            last = token;
            token = strtok(NULL, "/");
        }
        temp = atoi(last);
        
    }
}

// function to check algebra grade
void checkGradeAlgebra(float *algebra)
{
    
        while (*algebra > 20.0 || *algebra < 0.0)
        {
            printf("Invalide grade. Enter the information again: ");
            scanf("%f", algebra);
        }
    
}

// function to check calculus grade
void checkGradeCalculus(float *calculus)
{
    
        while (*calculus > 20.0 || *calculus < 0.0)
        {
            printf("Invalide grade. Enter the information again: ");
            scanf("%f", calculus);
        }
    
}

// function to check Basic Programming grade
void checkGradeBP(float *BP)
{
    
        while (*BP > 20.0 || *BP < 0.0)
        {
            printf("Invalide grade. Enter the information again: ");
            scanf("%f", BP);
        }
    
}
// function to calculate GPA
float calculateGPA(float *algebra, float *calculus, float *basicProgramming)
{
    float GPA = ((*algebra + *calculus + *basicProgramming) / 3);
    return GPA;
}

// function to print the student list
void printTable(student *a, int number)
{
    printf("| %-10s | %-30s | %-10s | %-7s | %-8s | %-16s | %-5s |\n",
           "ID", "Full Name", "Birthdate", "Algebra", "Calculus", "Basic Programming", "GPA");
    printf("|%s|\n", "-----------------------------------------------------------------------------------------------------------");

    for (int i = 0; i < number; i++)
    {
        a[i].GPA = calculateGPA(&a[i].algebra, &a[i].calculus, &a[i].basicProgramming);
        printf("| %10s | %-30s | %10s | %7.2f | %8.2f | %17.2f | %5.2f |\n",
               a[i].ID,
               a[i].fullName,
               a[i].birthDate,
               a[i].algebra,
               a[i].calculus,
               a[i].basicProgramming,
               a[i].GPA);
    }
}

// function to write table to text file
void writeToFile(int n, struct studentInfo *student)
{
    FILE *filePointer;
    filePointer = fopen("studentInfo.txt", "w");

    if (filePointer == NULL)
    {
        printf("Error!");
        exit(1);
    }

    fprintf(filePointer, "%30s|%15s|%15s|%10s|%10s|%20s|%10s\n", "Name", "ID", "Date of Birth", "Linear", "Calculus", "Basic Programming", "GPA");
    fprintf(filePointer, "====================================================================================================================\n");
    for (int i = 0; i < n; i++)
    {
        fprintf(filePointer, "%30s|%15s|%15s|%10.2f|%10.2f|%20.2f|%10.2f\n",
                student[i].fullName,
                student[i].ID,
                student[i].birthDate,
                student[i].algebra,
                student[i].calculus,
                student[i].basicProgramming,
                student[i].GPA);
    }
    fclose(filePointer);
}

// function to get the last name

void getLastName(char *fullName)
{
    char strOfFullName[50];
    strcpy(strOfFullName, fullName); 
    char *token, *last;
    last = token = strtok(strOfFullName, " ");

    while (token != NULL)
    {
        last = token;
        token = strtok(NULL, " ");
    }
    printf("The last name of %s is: %s\n", fullName, last);
}

// function to get first name
void getFirstName(char *fullName)
{
    char strOfFullName[50];
    strcpy(strOfFullName, fullName);
    printf("The first name of %s is: %s\n", fullName, strtok(strOfFullName, " "));
}


// function to print out the student with the highest GPA
void highestGPA(student *a, int number)
{
    float max = a[0].GPA;
    int highest_position = 0;
    for (int i = 0; i < number; i++)
    {
        if (a[i].GPA > max)
        {
            max = a[i].GPA;
            highest_position = i;
        }
    }
    printf("The student with the highest GPA is: %s with GPA is %.2f\n", a[highest_position].fullName, max);
}

// function to print out the student with the lowest GPA
void lowestGPA(student *a, int number)
{
    float min = a[0].GPA;
    int lowest_position = 0;
    for (int i = 0; i < number; i++)
    {
        if (a[i].GPA < min)
        {
            min = a[i].GPA;
            lowest_position = i;
        }
    }
    printf("The student with the lowest GPA is: %s with GPA is %.2f\n", a[lowest_position].fullName, min);
}

// function to print out the student with the highest Basic Programming grade
void highestBP(student *a, int number)
{
    float maxBP = a[0].basicProgramming;
    int position = 0;
    for (int i = 0; i < number; i++)
    {
        if (a[i].basicProgramming > maxBP)
        {
            maxBP = a[i].basicProgramming;
            position = i;
        }
    }
    printf("The student with the highest BP is: %s with Basic Programming grade is %.2f\n", a[position].fullName, maxBP);
}


// start function to sort GPA in descending order

// function to swap information
void swap(struct studentInfo *a, struct studentInfo *b)
{
    struct studentInfo t = *a; // temporary var
    *a = *b;
    *b = t;
}
// start sorting

int partitionGPA(student *a, int start, int end, bool descending)
{
    float pivot = a[end].GPA;
    int i = start - 1; // Index of smaller element and indicates the right position of pivot found so far

    for (int j = start; j <= end - 1; j++)
    {
        if (a[j].GPA >= pivot && descending)
        { // swap current element if it is bigger than the pivot
            i++;
            swap(&a[i], &a[j]);
        }
        if (a[j].GPA < pivot && !descending)
        { //  swap if current element is smaller than the pivot
            i++;
            swap(&a[i], &a[j]);
        }
    }
    i++;
    swap(&a[i], &a[end]);
    return i;
}

void quickSortGPA(student *a, int start, int end, bool descending)
{
    if (end <= start)
    {
        return;
    }

    float pivot = partitionGPA(a, start, end, descending);
    quickSortGPA(a, 0, pivot - 1, descending);   // sort the left side of pivot
    quickSortGPA(a, pivot + 1, end, descending); // sort the right side of pivot
}
// end sorting GPA

